
function botaoClicado (numero) 
{ 
    let res = document.getElementById('resultado'); 
    res.innerHTML = `<p>Você clicou no Botão ${numero}</p>`; }